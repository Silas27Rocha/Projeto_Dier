import { FiliacaoDto } from './filiacao.dto';

describe('FiliacaoDto', () => {
  it('should be defined', () => {
    expect(new FiliacaoDto()).toBeDefined();
  });
});
