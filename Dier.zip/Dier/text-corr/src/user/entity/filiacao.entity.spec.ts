import { FiliacaoEntity } from './filiacao.entity';

describe('FiliacaoEntity', () => {
  it('should be defined', () => {
    expect(new FiliacaoEntity()).toBeDefined();
  });
});
