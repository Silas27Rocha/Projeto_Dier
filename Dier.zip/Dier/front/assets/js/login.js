const constainer = document.getElementById('container');
const registroBtn = document.getElementById('registro');
const loginBtn = document.getElementById('login');

registroBtn.addEventListener('click', ()=>{
  constainer.classList.add("active");
});

loginBtn.addEventListener('click', ()=>{
  constainer.classList.remove("active");
});


// public/script.js
// document.getElementById('login-form').addEventListener('submit', function(event) {
//     event.preventDefault();
  
//     // Obter os valores dos campos de entrada
//     const username = document.getElementById('username').value;
//     const password = document.getElementById('password').value;
  
//     // Aqui você pode adicionar a lógica para autenticar o usuário
//     // Por enquanto, vamos apenas exibir os valores no console
//     console.log('Usuário:', username);
//     console.log('Senha:', password);
  
//     // Resetar os campos de entrada
//     document.getElementById('username').value = '';
//     document.getElementById('password').value = '';
//   });
  